export const TAGTYPES = [
    "power",
    "story",
    "weakness",
    "loadout",
    "relationship",
];
