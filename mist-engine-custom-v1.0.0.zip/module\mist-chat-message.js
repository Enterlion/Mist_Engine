export class MistChatMessage extends ChatMessage {
}
